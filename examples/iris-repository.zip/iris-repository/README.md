# Iris隔离运行示例

这是本项目编写的实验示例，不是已发表论文复现。

运行：python train.py --config /output/config.json --output /output
依赖：scikit-learn、numpy、matplotlib（默认镜像已包含）。
